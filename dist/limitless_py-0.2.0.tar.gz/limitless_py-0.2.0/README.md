# 🐍 limitless-py ⏱️  
**Dead-simple, pluggable rate limiting for Python — with zero dependencies.**  
Because *you’re not limited anymore.* 🚀  

---

## ⚡ Installation

```bash
pip install limitless-py

📊 Benchmarks

10,000 calls @ 100/sec limit
(Lower = faster, more precise) 

┌────────────────────┬──────────────┐
│ Implementation     │ Time         │
├────────────────────┼──────────────┤
│ limitless-py       │ 99.03 s      │
│ Manual sleep()     │ 99.03 s      │
│ ratelimit lib      │ 99.54 s      │
└────────────────────┴──────────────┘
💨 limitless-py matches raw manual performance — no wasted cycles, no overhead.


🧑‍💻 Author

Built with 💚 and too much caffeine by me.
PRs welcome. Bugs welcome. Chaos welcome.